<div class="col-md-12">
  <footer class="footer">
    <small class="slogon">
      <img class="brand-icon" src="https://dn-phphub.qbox.me/uploads/images/201612/12/1/iq7WQc2iuW.png?imageView2/1/w/34/h/34">
      <a href="http://estgroupe.com/">
        这只是一段测试
      </a>
    </small>
    <nav>
      <ul>
        <li><a href="{{ route('about') }}">关于</a></li>
      </ul>
    </nav>
  </footer>
</div>
