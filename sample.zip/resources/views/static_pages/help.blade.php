@extends('layouts.default')

@section('title','帮助页')

@section('content')
  <h1>帮助页</h1>
@stop
