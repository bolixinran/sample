<?php

namespace App\Policies;

use Illuminate\Auth\Access\HandlesAuthorization;
use App\Models\User;

class UserPolicy
{
    use HandlesAuthorization;

    public function update(User $currentUser, User $user)//这里的$currentUser会自动调用当前登陆的用户  如果存在的话
    {
        return $currentUser->id === $user->id;
    }
}
